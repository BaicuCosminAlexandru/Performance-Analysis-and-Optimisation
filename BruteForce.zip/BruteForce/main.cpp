// We will take into consideration the minimum requirements of a password:
// - minimum 6 characters

// The newer platforms require a standard minimum passwords requirements li:
// - minimum 6 characters
// - at least one upper case letter
// - at least a number
// - at least one special character like : !@#$%^&*()-=_+

//------------------------------------------------------------------
// Code to generate a random password up to 15 characters
//#include <iostream>
//#include <cstdlib>
//#include <ctime>
//#include <chrono>
//
//// Function to generate a random password
//std::string generateRandomPassword(int length) {
//    const std::string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-=_+";
//
//    srand(static_cast<unsigned int>(time(0))); // Seed for random number generation
//
//    std::string password;
//    for (int i = 0; i < length; ++i) {
//        int index = rand() % charset.length();
//        password += charset[index];
//    }
//
//    return password;
//}
//
//int main() {
//    int passwordLength;
//
//    // Get the desired password length from the user
//    std::cout << "Enter the length of the password (up to 15 characters): ";
//    std::cin >> passwordLength;
//
//    auto start = std::chrono::high_resolution_clock::now();
//    if (passwordLength > 1 && passwordLength <= 15) {
//        // Generate and display the random password
//        std::string password = generateRandomPassword(passwordLength);
//        std::cout << "Generated Password: " << password << std::endl;
//    } else {
//        std::cout << "Invalid password length. Please enter a value between 6 and 15." << std::endl;
//    }
//    auto stop = std::chrono::high_resolution_clock::now();
//    std::cout << "Done in " << duration_cast<std::chrono::milliseconds>(stop-start).count() << " ms" << std::endl;
//
//    return 0;
//}
//------------------------------------------------------------------

// Generated password : -6P=Fg$8y^W@&N(

//------------------------------------------------------------------
//// BruteForce script
// Naive implementation brute force
//  2 characters : 8 us         , avg time 1290 us for each password
//  3 characters :              , avg time 2302 us for each password
//  4 characters :              , avg time 91059 us for each password
//  5 characters :              , avg time 6 s for each password
//  6 characters :              , avg time 48 min 58s for password (master)
//  7 characters :              , avg time 16 hours for password (h6aqINN)
//  8 characters :              , avg time 2302 us for each password
//  9 characters :              , avg time 2302 us for each password
// 10 characters :              , avg time 2302 us for each password
// 11 characters :              , avg time 2302 us for each password
// 12 characters :              , avg time 2302 us for each password

#include <stdio.h>
#include <iostream>
#include <chrono>

using namespace std::chrono;

int compare_with_fixed_value(char *prefix, int length, char fixed_value[12]) {
    for (int i = 0; i < length; i++) {
        if (prefix[i] != fixed_value[i]) {
            return 0; // Not equal
        }
    }
    return 1; // Equal
}

void generate_combinations(int length, char *prefix, int level) {
    if (level == length) {
//        printf("%s\n", prefix);
        return;
    }

    for (int i = 32; i <= 126; i++) {
        prefix[level] = (char)i;
        prefix[level + 1] = '\0'; // Ensure null termination
        generate_combinations(length, prefix, level + 1);
    }
}

int main() {
    int length;
    printf("Enter the length of combinations: ");
    scanf("%d", &length);
//    char fixed_value[12];
//    printf("Enter the fixed value: ");
//    scanf("%s", fixed_value);
    printf("Generating combinations...\n");

    auto start = std::chrono::high_resolution_clock::now();
    char prefix[length + 1];    // +1 for null terminator
    prefix[length] = '\0';      // null terminator

    generate_combinations(length, prefix, 0);


    auto stop = high_resolution_clock::now();
    std::cout << "Done in " << duration_cast<microseconds >
            (stop-start).count() << " s" << std::endl;
    return 0;
}