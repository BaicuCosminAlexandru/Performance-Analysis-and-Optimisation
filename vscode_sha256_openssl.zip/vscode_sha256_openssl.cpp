﻿// vscode_sha256_openssl.cpp : Defines the entry point for the application.
//
#include "vscode_sha256_openssl.h"
#include <iostream>
#include <openssl/sha.h>
#include <string>
#include <chrono>

//vcpkg install openssl
//vcpkg new --application
//vcpkg add port openssl
//vcpkg install ?
//vcpkg install --triplet x64-windows
//vcpkg install integrate/integrate install
//set(OPENSSL_ROOT_DIR "${CMAKE_CURRENT_SOURCE_DIR}/vcpkg_installed/vcpkg/pkgs/openssl_x64-windows")
//find_package(OpenSSL REQUIRED COMPONENTS SSL Crypto)
//target_link_libraries(vscode_sha256_openssl PRIVATE OpenSSL::SSL OpenSSL::Crypto)

using namespace std::chrono;

using namespace std;


string sha256(const string& str)
{
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, str.c_str(), str.size());
    SHA256_Final(hash, &sha256);
    stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
    }
    return ss.str();
}

int main() {
    auto start = high_resolution_clock::now();
    for(int i=0; i<1000; i++)
        sha256("0") ;
    auto stop = high_resolution_clock::now();
    std::cout << "Done in " << duration_cast<milliseconds >(stop - start).count() << " ms" << std::endl;
    return 0;
}
