﻿// vscode_sha256_openssl.h : Include file for standard system include files,
// or project specific include files.

#pragma once

#include <iostream>
#include <stdio.h>
#include <vector>

// TODO: Reference additional headers your program requires here.
void sha256_encrypt(const uint8_t* data, size_t length, uint8_t* hash);
void thread_func(const uint8_t* data, int thread_id, std::vector<uint8_t>& output);