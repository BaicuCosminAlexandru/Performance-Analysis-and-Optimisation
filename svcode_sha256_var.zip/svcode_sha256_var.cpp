﻿
#include <iostream>
#include <vector>
#include <iomanip>
#include <random>
#include <cstring>
#include <array>
#include <ctime>
#include <chrono>
#include <algorithm>
#include <sstream>
#include <cstdint>
#include <fstream>

using namespace std::chrono;

const int MAX_VALUE_COUNT = 160000;
const int MIN_ASCII = 33; // ASCII value of '!'
const int MAX_ASCII = 126; // ASCII value of '~'

using BigInt512 = std::array<uint8_t, 64>;
using SHA256Hash = std::array<uint8_t, 32>;

// Constants for SHA-256 algorithm
constexpr uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

constexpr uint32_t H[8] = {
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
};

// Right rotate operation (Circular right shift)
constexpr uint32_t ROTR(uint32_t x, uint32_t n) {
    return (x >> n) | (x << (32 - n));
}

// Right shift operation
constexpr uint32_t SHR(uint32_t x, uint32_t n) {
    return x >> n;
}

// Sigma functions
constexpr uint32_t SIGMA0(uint32_t x) {
    return ROTR(x, 2) ^ ROTR(x, 13) ^ ROTR(x, 22);
}

constexpr uint32_t SIGMA1(uint32_t x) {
    return ROTR(x, 6) ^ ROTR(x, 11) ^ ROTR(x, 25);
}

constexpr uint32_t sigma0(uint32_t x) {
    return ROTR(x, 7) ^ ROTR(x, 18) ^ SHR(x, 3);
}

constexpr uint32_t sigma1(uint32_t x) {
    return ROTR(x, 17) ^ ROTR(x, 19) ^ SHR(x, 10);
}

// SHA-256 compression function and other utility functions
void sha256_compress(const uint8_t* data, uint32_t* hash) {
    uint32_t W[64];
    for (int i = 0; i < 16; ++i) {
        W[i] = (data[4 * i] << 24) | (data[4 * i + 1] << 16) | (data[4 * i + 2] << 8) | data[4 * i + 3];
    }
    for (int i = 16; i < 64; ++i) {
        W[i] = sigma1(W[i - 2]) + W[i - 7] + sigma0(W[i - 15]) + W[i - 16];
    }

    uint32_t a = hash[0];
    uint32_t b = hash[1];
    uint32_t c = hash[2];
    uint32_t d = hash[3];
    uint32_t e = hash[4];
    uint32_t f = hash[5];
    uint32_t g = hash[6];
    uint32_t h = hash[7];

    for (int i = 0; i < 64; ++i) {
        uint32_t T1 = h + SIGMA1(e) + ((e & f) ^ (~e & g)) + K[i] + W[i];
        uint32_t T2 = SIGMA0(a) + ((a & b) ^ (a & c) ^ (b & c));
        h = g;
        g = f;
        f = e;
        e = d + T1;
        d = c;
        c = b;
        b = a;
        a = T1 + T2;
    }

    hash[0] += a;
    hash[1] += b;
    hash[2] += c;
    hash[3] += d;
    hash[4] += e;
    hash[5] += f;
    hash[6] += g;
    hash[7] += h;
}

// Custom SHA-256 implementation
void sha256(const uint8_t* data, size_t len, uint8_t* out) {
    uint32_t hash[8] = { H[0], H[1], H[2], H[3], H[4], H[5], H[6], H[7] }; // Initial hash values

    uint8_t block[64] = { 0 };
    size_t blockSize = 0;

    // Process each 512-bit chunk
    for (size_t i = 0; i < len; i += 64) {
        if (len - i >= 64) {
            sha256_compress(data + i, hash);
        }
        else {
            memcpy(block, data + i, len - i);
            blockSize = len - i;
        }
    }

    // Add padding
    block[blockSize] = 0x80;
    if (blockSize >= 56) {
        sha256_compress(block, hash);
        memset(block, 0, 64);
    }

    uint64_t totalBits = len * 8;
    for (int i = 0; i < 8; ++i) {
        block[63 - i] = totalBits & 0xff;
        totalBits >>= 8;
    }
    sha256_compress(block, hash);

    for (int i = 0; i < 8; ++i) {
        out[i * 4] = (hash[i] >> 24) & 0xff;
        out[i * 4 + 1] = (hash[i] >> 16) & 0xff;
        out[i * 4 + 2] = (hash[i] >> 8) & 0xff;
        out[i * 4 + 3] = hash[i] & 0xff;
    }
}

// Function to generate a single ASCII combination of specified length
BigInt512 generateSingleASCIICombination(int length) {
    BigInt512 value = {}; // Start with all zeroes
    long long index = 0; // For simplicity, we use the first combination
    for (int j = length - 1; j >= 0; --j) {
        value[j] = MIN_ASCII + (index % (MAX_ASCII - MIN_ASCII + 1));
        index /= (MAX_ASCII - MIN_ASCII + 1);
    }
    return value;
}

// Function to encrypt a single value 1000 times
void encryptValueRepeatedly(const BigInt512& value, int repetitions, SHA256Hash& hash) {
    SHA256Hash currentHash = hash;
    for (int i = 0; i < repetitions; ++i) {
        sha256(value.data(), value.size(), currentHash.data());
    }
    hash = currentHash;
}

void writeToFile(const BigInt512& value, const SHA256Hash& hash, const std::string& valuesFilename, const std::string& hashesFilename) {
    std::ofstream valuesFile(valuesFilename, std::ios::out | std::ios::app); // Open file for writing values (append mode)
    std::ofstream hashesFile(hashesFilename, std::ios::out | std::ios::app); // Open file for writing hashes (append mode)

    if (!valuesFile.is_open()) {
        std::cerr << "Error: Unable to open values file for writing: " << valuesFilename << std::endl;
        return; // Exit function if unable to open values file
    }

    if (!hashesFile.is_open()) {
        std::cerr << "Error: Unable to open hashes file for writing: " << hashesFilename << std::endl;
        valuesFile.close(); // Close the values file
        return; // Exit function if unable to open hashes file
    }

    std::cout << "Writing value and hash to files..." << std::endl;

    // Write value in hexadecimal format
    for (auto byte : value) {
        valuesFile << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
    }
    valuesFile << "\n";

    // Write hash in hexadecimal format
    for (auto byte : hash) {
        hashesFile << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
    }
    hashesFile << "\n";

    valuesFile.close();
    hashesFile.close();
}

int main() {
    BigInt512 value = { 0 };
    SHA256Hash hash;
    auto start = high_resolution_clock::now();
    encryptValueRepeatedly(value, 100, hash);
    auto encEnd = std::chrono::high_resolution_clock::now();
    auto stop = high_resolution_clock::now();
    std::cout << "Done in " << duration_cast<microseconds>(stop - start).count() << " us" << std::endl;

    writeToFile(value, hash, "single_value.txt", "single_hash.txt");

    return 0;
}